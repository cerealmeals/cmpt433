#ifndef GPIO_EVENTS_H
#define GPIO_EVENTS_H

void gpio_events_init();
void gpio_events_cleanup();

#endif // GPIO_EVENTS_H
