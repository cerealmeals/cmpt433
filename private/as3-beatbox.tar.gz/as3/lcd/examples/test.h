/*****************************************************************************
* | File        :   trst.h
* | Author      :   Waveshare team
* | Function    :   
* | Info        :
*
*----------------
* | This version:   V1.0
* | Date        :   2020-05-20
* | Info        :   Basic version
*
******************************************************************************/

#ifndef _TRST_H_
#define _TRST_H_




void    LCD_0IN96_test(void);

void    LCD_1IN14_test(void);

void    LCD_1IN28_test(void);

void    LCD_1IN3_test(void);

void    LCD_1IN47_test(void);

void    LCD_1IN54_test(void);

void	LCD_1IN69_test(void);

void    LCD_1IN8_test(void);

void    LCD_1IN9_test(void);

void    LCD_2IN_test(void);

void    LCD_2IN4_test(void);





#endif